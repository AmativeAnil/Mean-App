var app = angular.module("myToDoList", []);
app.controller("myCtrl", function($scope) {
    $scope.products = ["HTML", "CSS", "JavaScript"];
    $scope.addItem = function () {
        $scope.errortext = "";
        if (!$scope.work) {return;}
        if ($scope.products.indexOf($scope.work) == -1) {
            $scope.products.push($scope.work);
            $scope.work = "";
        } else {
            $scope.errortext = "The item is already in your shopping list.";
        }
    }
    $scope.removeItem = function (x) {
        $scope.errortext = "";
        $scope.products.splice(x, 1);
    }
});